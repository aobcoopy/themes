<?php
/**
* WooCommerce Default Shop Page
*
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/
*
* @package kinsley
*/

get_header();
?>

<?php get_template_part( 'woocommerce/wc-template' ); ?>

<?php
get_footer();
