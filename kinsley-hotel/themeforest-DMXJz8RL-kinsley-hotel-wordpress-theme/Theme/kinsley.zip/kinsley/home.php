<?php
/**
 * The template for displaying all posts
 *
 * @package kinsley
 */

get_template_part( 'index' );

?>
